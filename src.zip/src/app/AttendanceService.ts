// attendance.service.ts
import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import baseUrl from './commonurl';
import { User } from './tsfiles/user';


@Injectable({
  providedIn: 'root',
})
export class AttendanceService {
    private lastAttendanceDate: Date | null = null;

    createAttendanceRecord() {
      const currentDate = new Date();
  
      if (this.lastAttendanceDate && currentDate.getDate() === this.lastAttendanceDate.getDate()) {
        return false; // Attendance already created for the day
      }
  
      // Create a new attendance record here
  
      // Update the lastAttendanceDate
      this.lastAttendanceDate = currentDate;
  
      return true; // Attendance created successfully
    }

  getAttendanceRecords() {
    // Retrieve attendance records here
  }
}
